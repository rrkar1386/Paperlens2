package com.smartpdf.reader;

import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.util.regex.Pattern;

public class ReflowEngine {

    /*
     * V0.1 deliberately keeps this engine conservative.
     * It preserves original PDF page boundaries and exposes a direct
     * "Original PDF page N" link. The next iteration will add coordinate-aware
     * column detection and semantic blocks (figure/caption/table/question/answer).
     */
    public static String buildHtml(File file) throws Exception {
        StringBuilder out = new StringBuilder();
        out.append("<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>");
        out.append("<style>");
        out.append("body{font-family:serif;margin:0;padding:0 18px 50px;line-height:1.55;color:#171717;background:#fff}");
        out.append("h1,h2,h3{font-family:sans-serif;line-height:1.2}");
        out.append(".top{position:sticky;top:0;background:#fff;padding:12px 0;border-bottom:1px solid #ddd;font-family:sans-serif;font-size:14px}");
        out.append(".page{padding:18px 0 28px;border-bottom:1px solid #ddd}");
        out.append(".marker{font-family:sans-serif;font-size:13px;color:#666;margin-bottom:14px}");
        out.append("p{margin:0 0 1em;white-space:normal}");
        out.append("a{color:#234b9b}");
        out.append("</style></head><body>");
        out.append("<div class='top'><b>Smart PDF Reader</b><br>Continuous phone reading · original PDF retained</div>");

        try (PDDocument doc = PDDocument.load(file)) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);

            for (int p = 1; p <= doc.getNumberOfPages(); p++) {
                stripper.setStartPage(p);
                stripper.setEndPage(p);
                String text = stripper.getText(doc).trim();

                out.append("<section class='page'>");
                out.append("<div class='marker'>Original PDF page ").append(p)
                   .append(" · <a href='app://page/").append(p).append("'>Open original PDF page</a></div>");

                String[] paragraphs = text.split("\\n\\s*\\n");
                for (String para : paragraphs) {
                    String cleaned = para.replaceAll("\\s*\\n\\s*", " ").trim();
                    if (cleaned.isEmpty()) continue;

                    if (cleaned.length() < 120 && cleaned.matches(".*[A-Za-z].*")) {
                        out.append("<h2>").append(esc(cleaned)).append("</h2>");
                    } else {
                        out.append("<p>").append(esc(cleaned)).append("</p>");
                    }
                }
                out.append("</section>");
            }
        }

        out.append("</body></html>");
        return out.toString();
    }

    private static String esc(String s) {
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
}
