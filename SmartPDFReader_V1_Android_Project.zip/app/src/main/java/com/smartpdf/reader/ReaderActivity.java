package com.smartpdf.reader;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ReaderActivity extends AppCompatActivity {

    private File pdfFile;
    private PdfRenderer renderer;
    private ParcelFileDescriptor pfd;
    private int currentPage = 0;

    private FrameLayout contentFrame;
    private WebView webView;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reader);

        contentFrame = findViewById(R.id.contentFrame);

        findViewById(R.id.readingButton).setOnClickListener(v -> showReadingView());
        findViewById(R.id.originalButton).setOnClickListener(v -> showOriginalView());
        findViewById(R.id.jumpButton).setOnClickListener(v -> showPageDialog());

        try {
            PDFBoxResourceLoader.init(getApplicationContext());
            copyUriToCache();
            openRenderer();
            showReadingView();
        } catch (Exception e) {
            Toast.makeText(this, "Could not open PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void copyUriToCache() throws Exception {
        File dir = new File(getCacheDir(), "smartpdf");
        if (!dir.exists()) dir.mkdirs();
        pdfFile = new File(dir, "current.pdf");

        try (InputStream in = getContentResolver().openInputStream(getIntent().getData());
             FileOutputStream out = new FileOutputStream(pdfFile)) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
    }

    private void openRenderer() throws Exception {
        pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
        renderer = new PdfRenderer(pfd);
    }

    private void showReadingView() {
        contentFrame.removeAllViews();

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(false);
        webView.getSettings().setDefaultTextEncodingName("utf-8");
        webView.setBackgroundColor(0xFFFFFFFF);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("app://page/")) {
                    try {
                        int page = Integer.parseInt(url.substring("app://page/"));
                        showOriginalPage(page - 1);
                    } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });

        contentFrame.addView(webView);
        new Thread(() -> {
            String html;
            try {
                html = ReflowEngine.buildHtml(pdfFile);
            } catch (Exception e) {
                html = "<html><body><h2>Reading view unavailable</h2><p>" +
                        escape(e.getMessage()) + "</p></body></html>";
            }
            String finalHtml = html;
            runOnUiThread(() -> webView.loadDataWithBaseURL(null, finalHtml, "text/html", "UTF-8", null));
        }).start();
    }

    private void showOriginalView() {
        showOriginalPage(currentPage);
    }

    private void showOriginalPage(int pageIndex) {
        if (renderer == null) return;
        if (pageIndex < 0) pageIndex = 0;
        if (pageIndex >= renderer.getPageCount()) pageIndex = renderer.getPageCount() - 1;
        currentPage = pageIndex;

        contentFrame.removeAllViews();
        imageView = new ImageView(this);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        contentFrame.addView(imageView);

        PdfRenderer.Page page = renderer.openPage(currentPage);
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = Math.max(1, (int) (width * page.getHeight() / (float) page.getWidth()));
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(0xFFFFFFFF);
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        page.close();
        imageView.setImageBitmap(bitmap);
        setTitle("Original PDF • page " + (currentPage + 1) + "/" + renderer.getPageCount());
    }

    private void showPageDialog() {
        final EditText input = new EditText(this);
        input.setHint("Original PDF page number");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        LinearLayout box = new LinearLayout(this);
        box.setPadding(40, 10, 40, 0);
        box.addView(input, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(this)
                .setTitle("Go to original PDF page")
                .setView(box)
                .setPositiveButton("Open", (d, w) -> {
                    try {
                        int p = Integer.parseInt(input.getText().toString());
                        if (p >= 1 && p <= renderer.getPageCount()) {
                            showOriginalPage(p - 1);
                        } else {
                            Toast.makeText(this, "Page must be 1–" + renderer.getPageCount(), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(this, "Enter a page number", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { if (renderer != null) renderer.close(); } catch (Exception ignored) {}
        try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
    }
}
