# Smart PDF Reader V1 — Android prototype

## What this prototype proves

1. Import a real PDF from the Android phone.
2. Keep the original PDF locally available inside the app.
3. Generate a continuous phone-reading view.
4. Keep a source-page marker for every reflowed page.
5. Tap a source-page link to open the corresponding original PDF page **inside the app**.
6. Use one scalable **Go to page** control instead of hundreds of page buttons.

## Current deliberate limitation

V0.1 does **not** yet attempt the full semantic reading-order algorithm demonstrated by the hand-refined HTML/PDF experiments.

The next engine iteration will add:

- coordinate-aware single/two-column detection
- paragraph continuation across columns/pages
- figure/caption grouping
- table/paired-layout preservation
- thought-question → blank-answer-space preservation
- better heading detection
- printed-page vs PDF-page mapping

The 12-page Pathology of Cancer PDF is the benchmark for these tests.

## Build

This repository is designed for the user's phone-only GitHub Actions workflow.

Run:

`Actions → Build Smart PDF Reader APK → Run workflow`

Download artifact:

`SmartPDFReader-V1-debug`
